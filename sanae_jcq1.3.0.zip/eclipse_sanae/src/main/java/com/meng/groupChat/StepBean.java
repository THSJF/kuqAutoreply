package com.meng.groupChat;

public class StepBean {
	public static final int addQuestion=1;
	public static final int addAnswer=2;

	public long qq=0;
	public int step=0;
	public String s1=null;
	public String s2=null;
}
