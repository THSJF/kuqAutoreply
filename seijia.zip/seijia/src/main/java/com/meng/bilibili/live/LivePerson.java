package com.meng.bilibili.live;

public class LivePerson {
	public String liveUrl = "";
	public boolean lastStatus = false;
	public boolean needTip = false;
	public long liveStartTimeStamp = 0;
	public String roomID="";
}
